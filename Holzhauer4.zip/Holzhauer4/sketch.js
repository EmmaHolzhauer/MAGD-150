

function setup() {
  createCanvas(400,400);
    colorMode (RGB, 225,225,225,1)
    frameRate (38);
}

let value = 0;
function draw() {
    background (176,196,222);
    
    stroke(0);
    fill(255);
    text(mouseX + "," + mouseY, 20,20);
    
    stroke(225);
  for (var i = 20; i < 500; i += 40) {
  	line(i, 1, i + 30, 390);
  }
    
    if (keyIsPressed) {
    if (key == 'm') {
    noStroke (0);
    fill (value);
    ellipse (200,180, 100,100); //middle of snowman
    ellipse (200, 110, 70, 70); //head of snowman
    fill(0);
    ellipse (180, 100, 10, 10); //left eye
    ellipse (220, 100, 10, 10); //right eye
    ellipse (200, 110, 10, 10); //nose
    ellipse (180, 119, 5, 5);//smile from L to Rm
    ellipse (190, 123, 5, 5); 
    ellipse (200, 125, 5, 5);
    ellipse (210, 123, 5, 5) ;
    ellipse (220, 119, 5, 5);
    ellipse (200, 160, 10, 10);//buttons T to B
    ellipse (200, 180, 10, 10); 
    ellipse (200, 200, 10, 10);
    }
 }
    noStroke(0);
    fill(210);
    rect(0,330, 400,100); //snow at bottom
    fill(value);
    noStroke(0);
    ellipse(200, 280, 150, 150); //bottom of snowman
    describe(`black 50-by-50 rect turns white with mouse click/press.`);
}
    
function mouseClicked() {
colorMode (RGB, 225,225,225,1);
  if (value === 0) {
    value = (225);
  } else {
    value = (0);
  }
} 
