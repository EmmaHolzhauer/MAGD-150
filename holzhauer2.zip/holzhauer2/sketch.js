function setup() {
  createCanvas(400, 400);
}

function draw() {
background(220);
fill(250)
noStroke(0)
text(mouseX + "," + mouseY, 20,20)
    rect(0,340,400,400)
    angleMode(DEGREES)
  translate(200, 0);
  for (let i = 0; i < 10; i++) {
    push();
    translate(0, i*41);
    rotate(i * (mouseX/width) * 0.5);
    scale(0.5 + i * (mouseY/height) * 0.1);
  	ellipse(0, 0, 25, 27);
    pop();
      let x = 10;
print('The value of x is ' + x);
    }
  }
