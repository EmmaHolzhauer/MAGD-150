
var img1;
var img2;
var img3;

function preload() {
	img1 = loadImage("puppy.jpg");
	img2 = loadImage("adult.jpg");
	img3 = loadImage("bird.gif");
}

function setup () {
	createCanvas(600, 600);
	background (200)
}

function draw () {

	textFont ("Gotham");
	fill(0, 102, 50);
	stroke (20);
	textSize(100);
	text('DOG', 330, 550);

	text(str, 300, 600, [300], [200])
	noStroke(0);
	textSize(30);
	fill(0, 102, 153);
	text('...and bird', 330, 580);



	image(img1, 0, 0);
	image(img1, 0, 300, mouseX / 2, mouseY / 2);
	image(img2, 300, 0);
	image(img3, 280,30);
	image(img3, 0, 310, mouseX * .2, mouseY * .2);

}
